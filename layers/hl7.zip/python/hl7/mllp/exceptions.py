class InvalidBlockError(Exception):
    """An MLLP Block was received that violates MLLP protocol"""
